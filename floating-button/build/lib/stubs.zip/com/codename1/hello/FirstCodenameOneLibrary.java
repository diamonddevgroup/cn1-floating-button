package com.codename1.hello;


/**
 *  This is a demo class to help you get started building a library
 * 
 *  @author Your name here
 */
public class FirstCodenameOneLibrary {

	public FirstCodenameOneLibrary() {
	}

	/**
	 *  Method javadoc information
	 */
	public void hello() {
	}
}
